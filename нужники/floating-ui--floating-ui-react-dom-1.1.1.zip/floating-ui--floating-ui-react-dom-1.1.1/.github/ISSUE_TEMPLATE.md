<!--

Please use one of the following CodeSandboxes to reproduce your issue and make sure not to include any external libraries:

- @floating-ui/dom: https://codesandbox.io/s/floating-ui-dom-template-utpx0u
- @floating-ui/react-dom: https://codesandbox.io/s/floating-ui-react-dom-template-qfufud?file=/src/App.js

-->
