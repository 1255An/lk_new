module.exports = {
  presets: [['@babel/env', {loose: true}], '@babel/typescript', '@babel/react'],
};
