# @floating-ui/react

This is the library to use Floating UI with React.
