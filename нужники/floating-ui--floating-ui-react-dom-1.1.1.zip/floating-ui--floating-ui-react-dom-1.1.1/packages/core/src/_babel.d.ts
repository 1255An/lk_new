declare const __DEV__: boolean;
