# @floating-ui/dom

This is the library to use Floating UI on the web, wrapping `@floating-ui/core`
with DOM interface logic.
