declare module 'vanilla-js-wheel-zoom';
