module.exports = {
    bracketSpacing: true,
    tabWidth: 4,
    semi: true,
    singleQuote: true
};
